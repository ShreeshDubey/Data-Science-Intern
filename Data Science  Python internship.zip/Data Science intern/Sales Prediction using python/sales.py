import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt

df = pd.read_csv(r'D:\Data Science intern\Sales Prediction using python\Advertising.csv')

print("Given Sample data:")
print(df.to_string(index=False))
print()

X = df[['Seq','TV', 'Radio', 'Newspaper']]
y = df['Sales']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)

mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Evaluation Metrics:")
print("Mean Squared Error: {:.4f}".format(mse))
print("R-squared: {:.4f}".format(r2))

print("Coefficients:")
for feature, coefficient in zip(X.columns, model.coef_):
    print("{}: {:.4f}".format(feature, coefficient))

new_data = [[1, 100, 100, 100]]
prediction = model.predict(new_data)

print("Predicted sales: {:.2f}".format(prediction[0]))

plt.scatter(y_test, y_pred, c='blue', label='Predicted Sales')
plt.scatter(y_test, y_test, c='red', label='Actual Sales')
plt.xlabel('Actual Sales')
plt.ylabel('Predicted Sales')
plt.legend()
plt.show()
