import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Read the CSV file into a Pandas DataFrame
df = pd.read_csv(r"D:\Data Science intern\Unemployment Analysis\archive\Unemployment in India.csv")

# Clean column names
df.columns = df.columns.str.strip()  # Remove leading/trailing spaces from column names

# Convert "Date" column to datetime data type
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True)

# Calculate the unemployment rate
df["Unemployment Rate"] = (df["Estimated Unemployment Rate (%)"] / (
        df["Estimated Employed"] + df["Estimated Unemployment Rate (%)"])) * 100

# Data Analysis

# Calculate the unemployment rate by region
region_unemployment_rates = df.groupby("Region")["Unemployment Rate"].mean().sort_values(ascending=False)

# Print the unemployment rate for each region
for region, unemployment_rate in region_unemployment_rates.items():
    print(f"The unemployment rate in {region} is {unemployment_rate:.2f}%")

# Calculate the unemployment rate by frequency
frequency_unemployment_rates = df.groupby("Frequency")["Unemployment Rate"].mean()

# Print the unemployment rate for each frequency
for frequency, unemployment_rate in frequency_unemployment_rates.items():
    print(f"The unemployment rate for {frequency} is {unemployment_rate:.2f}%")

# Data Visualization

# Plot the unemployment rate over time
plt.figure(figsize=(12, 6))
sns.lineplot(x="Date", y="Unemployment Rate", data=df, color="b")
plt.xlabel("Date")
plt.ylabel("Unemployment Rate (%)")
plt.title("Unemployment Rate Over Time")
plt.xticks(rotation=45)
plt.show()

# Plot the average unemployment rate by region
plt.figure(figsize=(12, 6))
sns.barplot(x=region_unemployment_rates.index, y=region_unemployment_rates.values, color="b")
plt.xlabel("Region")
plt.ylabel("Unemployment Rate (%)")
plt.title("Average Unemployment Rate by Region")
plt.xticks(rotation=45)
plt.show()

# Plot the unemployment rate by frequency over time
plt.figure(figsize=(12, 6))
sns.lineplot(x="Date", y="Unemployment Rate", hue="Frequency", data=df)
plt.xlabel("Date")
plt.ylabel("Unemployment Rate (%)")
plt.title("Unemployment Rate by Frequency")
plt.legend(title="Frequency", bbox_to_anchor=(1, 1))
plt.xticks(rotation=45)
plt.show()

# Read the CSV file into a Pandas DataFrame
df = pd.read_csv(r"D:\Data Science intern\Unemployment Analysis\archive\Unemployment_Rate_upto_11_2020.csv")

# Clean column names
df.columns = df.columns.str.strip()

# Convert "Date" column to datetime data type
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True)

# Calculate the unemployment rate
df["Unemployment Rate"] = (df["Estimated Unemployment Rate (%)"] / (
        df["Estimated Employed"] + df["Estimated Unemployment Rate (%)"])) * 100

# Data Analysis

# Calculate the unemployment rate by region
region_unemployment_rates = df.groupby("Region2")["Unemployment Rate"].mean().sort_values(ascending=False)

# Print the unemployment rate for each region
for region, unemployment_rate in region_unemployment_rates.items():
    print(f"The unemployment rate in {region} is {unemployment_rate:.2f}%")

# Calculate the unemployment rate by frequency
frequency_unemployment_rates = df.groupby("Frequency")["Unemployment Rate"].mean()

# Print the unemployment rate for each frequency
for frequency, unemployment_rate in frequency_unemployment_rates.items():
    print(f"The unemployment rate for {frequency} is {unemployment_rate:.2f}%")

# Data Visualization

# Plot the unemployment rate over time
plt.figure(figsize=(12, 6))
sns.lineplot(x="Date", y="Unemployment Rate", data=df, color="b")
plt.xlabel("Date")
plt.ylabel("Unemployment Rate (%)")
plt.title("Unemployment Rate Over Time")
plt.xticks(rotation=45)
plt.show()

# Plot the average unemployment rate by region
plt.figure(figsize=(12, 6))
sns.barplot(x=region_unemployment_rates.index, y=region_unemployment_rates.values, color="b")
plt.xlabel("Region")
plt.ylabel("Unemployment Rate (%)")
plt.title("Average Unemployment Rate by Region")
plt.xticks(rotation=45)
plt.show()

# Plot the unemployment rate by frequency over time
plt.figure(figsize=(12, 6))
sns.lineplot(x="Date", y="Unemployment Rate", hue="Frequency", data=df)
plt.xlabel("Date")
plt.ylabel("Unemployment Rate (%)")
plt.title("Unemployment Rate by Frequency")
plt.legend(title="Frequency", bbox_to_anchor=(1, 1))
plt.xticks(rotation=45)
plt.show()

